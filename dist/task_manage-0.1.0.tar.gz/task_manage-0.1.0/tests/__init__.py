
# to turn the directory into a package